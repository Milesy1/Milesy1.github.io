function RandomColour() {
	return [int(random()*255), int(random()*255), int(random()*255)];
}