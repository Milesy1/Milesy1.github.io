class Point
{
	constructor()
	{
		this.x = 2*random()-1;
		this.y = 2*random()-1;
		this.z = 2*random()-1;
		this.colour = RandomColour();
	}
	
	Update(dt, sigma, rho, beta)
	{
		let dxdt = sigma*(this.y-this.x);
		let dydt = this.x*(rho-this.z) - this.y;
		let dzdt = this.x * this.y - beta*this.z;
		
		this.x += dt*dxdt;
		this.y += dt*dydt;
		this.z += dt*dzdt;
	}
}