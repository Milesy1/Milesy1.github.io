function setup() {
	createCanvas(windowWidth, windowHeight);
	for (let element of document.getElementsByClassName("p5Canvas")) {
    element.addEventListener("contextmenu", (e) => e.preventDefault());
  }
	background(0);
	frameRate(240);
	
	LORENZ = new Lorenz(100);
}

function mouseDragged() {LORENZ.Pan();}
function mouseWheel(e) {LORENZ.Zoom(e.delta);}

function draw() {
	clear();
	LORENZ.Update();
	LORENZ.Blit();
}