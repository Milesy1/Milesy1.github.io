var settings = QuickSettings.create(0, 0, "Settings", null);
settings.addNumber("σ", -Infinity, Infinity, 10, 0, (val)=>{
	LORENZ.sigma = float(settings.getValue("σ"));
});
settings.addNumber("⍴", -Infinity, Infinity, 28, 0, (val)=>{
	LORENZ.rho = float(settings.getValue("⍴"));
});
settings.addNumber("β", -Infinity, Infinity, 8/3, 0, (val)=>{
	LORENZ.sigma = float(settings.getValue("β"));
});
settings.addNumber("No. points", 1, Infinity, 100, 1, null);
settings.addRange("Timestep", 0, 0.02, 0.01, 0.001, (val)=>{
	LORENZ.dt = float(settings.getValue("Timestep"));
});
settings.addRange("Thickness", 0, 0.5, 0.1, 0.001, (val)=>{
	LORENZ.strokeWeight = float(settings.getValue("Thickness"));
});
settings.addDropDown("Horizontal Axis", ["x","y","z"], (val)=>{
	LORENZ.horizontal = val.value;
});
settings.addDropDown("Vertical Axis", ["z","x","y"], (val)=>{
	LORENZ.vertical = val.value;
});
settings.addButton("Reset", ()=>{
	let p = (int(settings.getValue("No. points")));
	LORENZ.Reset(p);
});