const SZE = 400;
const palettes = ([
  ["#ff2a2d", "#f19700", "#f5d928", "#00e628", "#0a9cf5"],
  ["#009688", "#0a9cf5", "#35cbf9", "#3d99cd", "#2f70ad"],
  ["#ff184c", "#ff577d", "#ff3cfc", "#0a9cf5", "#35cbf9"],
]).map((p) => p.map((e) => e + "90"));

let palette, objs, rotScene;

let imgs;
function preload() {
  imgs = [];
  // imgs[0] = loadImage("https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/458877735f.jpg/1024px-458877735f.jpg")
}

function setup() {
  createCanvas(windowWidth, windowWidth*.75, WEBGL);
  setAttributes("antialias", true);
  fill(128, 0, 0, 192);
  strokeWeight(1);
  noStroke();
  palette = random(palettes);
  loop();

  const dx = 100;
  const dy = 40;
  const dz = 50;

  const dimS = { x: -50, y: 10, z: 10 };
  const dimE = { x: 50, y: 40, z: 40 };
  const rotM = { x: 0, y: 0, z: 0 };

  const numX = 10;
  const numZ = 15;
  objs = [];
	objs.push(new BCube(0, 0, 0, SZE))
	// objs.push(new BCube(-SZE, 0, 0, SZE))
	// objs.push(new BCube(SZE, 0, 0, SZE))

  rotScene = {x: random(-0.2, -0.5), y: random(-0.4, 0.4), z: 0}
}

function doubleClicked() {
  if (mouseButton === LEFT) {
    setup();
		// subdivide();
  }
}

function subdivide() {
	// let o = random(objs);
	const idx = objs.length - ~~sqrt(random(pow(objs.length, 2))) - 1;
	let o = objs[idx];
	
	if (o.s > SZE * 0.05) {
		// split obj
		o.split(objs);
		// remove random obj
		if (random() < 0.5) objs.splice(~~random(objs.length), 1);	
		// remove objs not in the edge
		if (true) {
			const S = SZE * 0.7;
			objs = objs.filter((o) => (o.isBorder(SZE)));
		}
		
	}
}

function draw() {
  background("white");
	// drawStats();

	if (frameCount % 10 === 0) subdivide();
  
  // sky bg
  if (true && imgs && imgs.length) {
    push()
    translate(0, 0, -500)
    imageMode(CENTER)
    image(imgs[0], map(mouseX, 0, width, 50, 0), -imgs[0].height*0.35, imgs[0].width*2.5, imgs[0].height*2.5)
    pop()
  }

  orbitControl();
  ambientLight("white");
  // lights();

  // random rotation
  if (false && rotScene) {
    rotateX(rotScene.x);
    rotateY(rotScene.y);
    rotateZ(rotScene.z);
  } else {
		rotateX(frameCount * 0.005);
		rotateY(frameCount * 0.007);
		rotateZ(frameCount * 0.001);
	}
  
  let locX = mouseX - width / 2;
  let locY = mouseY - height / 2;
  pointLight(255, 255, 255, locX, locY, height/2);

  // ground circle
  if (false) {
    push();
    translate(0, 1, 0);
    rotateX(HALF_PI);
    fill(16, 0, 64);
    let diam = max(width, height) * 2;
    ellipse(0, 0, diam, diam, 100);
    pop();
  }

  for (let o of objs) {
		o.show(palette, SZE * 0.01);
  }
}

function drawStats() {
  push()
  noStroke()
	fill("white")
	
	let areBorder = 0;
	for (let o of objs) {
		if (o.isBorder(SZE)) areBorder++;
	}
	
	const gr = createGraphics(100, 100);
  gr.noStroke()
	gr.fill("white")
	const msg = "" + areBorder + "/" + objs.length;
	gr.text(msg, 0, 10)
	
	image(gr, -width/2, -height/2)
	
  pop();
}

function keyPressed(){
  save("img_" + month() + '-' + day() + '_' + hour() + '-' + minute() + '-' + second() + ".jpg");
}