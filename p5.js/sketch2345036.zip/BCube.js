class BCube {
	constructor(x, y, z, s) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.s = s;
	}
	
	show(palette, d = 10) {
		push()
		translate(this.x, this.y, this.z)
		const n = noise(this.x, this.y, this.z)
		fill(palette[~~(n*palette.length)]);
		// specularMaterial(palette[~~(n*palette.length)]);
		box(this.s - d)
		pop()
	}
	
	split(objs) {
		const x = this.x;
		const y = this.y;
		const z = this.z;
		const s = this.s * 0.25;

		// create childs
		objs.push(new BCube(x-s, y-s, z-s, s+s))
		objs.push(new BCube(x-s, y-s, z+s, s+s))
		objs.push(new BCube(x-s, y+s, z-s, s+s))
		objs.push(new BCube(x-s, y+s, z+s, s+s))
		objs.push(new BCube(x+s, y-s, z-s, s+s))
		objs.push(new BCube(x+s, y-s, z+s, s+s))
		objs.push(new BCube(x+s, y+s, z-s, s+s))
		// objs.push(new BCube(x + s, y + s, z + s, s+s))
		
		// alter this obj (instead of creating new one and deleting this)
		this.x = x + s;
		this.y = y + s;
		this.z = z + s;
		this.s = s + s;
	}
	
	isBorder(S) {
		S *= 0.5;
		const D	= 0.01; // deviation
		const o = this;
		// console.log(S, this);
		const s = this.s * 0.5;
		return o.x + s > S-D || o.x - s < -S+D ||
				o.y + s > S-D || o.y - s < -S+D ||
				o.z + s > S-D || o.z - s < -S+D
	}
}