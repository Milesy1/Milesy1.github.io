
function setup() {
    initializeFields();
    createCanvas(1400, 400);
    background(250);
    noFill();
    stroke(0, 20);
    frameRate(1000);
}

function draw() {
    var t = float(frameCount);
    translate(t / 2, height / 2);
    rotate(t / 150);
    // ellipse(sin(t/50)*t/10, cos(t/50)*t/10,50,50);
    ellipse(0, 0, sin(t / 100) * t / 2, cos(t / 100) * t / 6);
}

function initializeFields() {
}

